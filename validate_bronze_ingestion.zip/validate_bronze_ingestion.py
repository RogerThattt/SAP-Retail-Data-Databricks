# validate_bronze_ingestion.py
# Databricks notebook source

from pyspark.sql.functions import col
from pyspark.sql.utils import AnalysisException

# List of bronze tables to validate
bronze_tables = [
    "sap_pos_transactions_bronze",
    "sap_product_master_bronze"
]

def validate_table_exists(table_name):
    try:
        spark.read.table(table_name).limit(1)
        print(f"✅ Table '{table_name}' exists.")
        return True
    except AnalysisException:
        print(f"❌ Table '{table_name}' does NOT exist.")
        return False

def validate_row_count(table_name):
    df = spark.read.table(table_name)
    count = df.count()
    print(f"📊 Table '{table_name}' has {count} rows.")
    if count == 0:
        print(f"⚠️ Table '{table_name}' is EMPTY.")
    return count > 0

def validate_schema(table_name, expected_columns):
    df = spark.read.table(table_name)
    actual_cols = set(df.columns)
    expected_cols = set(expected_columns)
    missing = expected_cols - actual_cols
    extra = actual_cols - expected_cols
    if missing:
        print(f"❌ Missing columns in '{table_name}': {missing}")
    if extra:
        print(f"ℹ️ Extra columns in '{table_name}': {extra}")
    if not missing:
        print(f"✅ Schema looks good for '{table_name}'")
    return len(missing) == 0

# Define expected columns for each table
expected_schemas = {
    "sap_pos_transactions_bronze": ["transaction_id", "material_id", "store_id", "quantity", "unit_price", "timestamp"],
    "sap_product_master_bronze": ["material_id", "description", "category", "brand"]
}

# Validation logic
for table in bronze_tables:
    print(f"--- Validating table: {table} ---")
    exists = validate_table_exists(table)
    if exists:
        row_check = validate_row_count(table)
        schema_check = validate_schema(table, expected_schemas[table])
        if row_check and schema_check:
            print(f"✅ Table '{table}' passed all validations.\n")
        else:
            print(f"⚠️ Table '{table}' failed validations.\n")
    else:
        print(f"❌ Skipping further validation for '{table}' because it does not exist.\n")
