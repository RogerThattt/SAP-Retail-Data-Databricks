# Retail DLT Pipeline

This repository contains a modular Delta Live Tables (DLT) pipeline for transforming SAP retail data into analytics-ready and business-friendly tables.

## Structure

- **bronze/**: Raw ingestion from SAP sources
- **silver/**: Clean, enrich, validate
- **gold/**: KPI aggregations
- **config/**: Paths and schema config
- **tests/**: Unit test scaffolds

## Git Integration with Databricks Repos

1. Initialize a Git repo:
    ```bash
    git init
    git remote add origin <your-repo-url>
    ```

2. Push the project:
    ```bash
    git add .
    git commit -m "Initial commit of retail DLT pipeline"
    git push -u origin main
    ```

3. In Databricks:
   - Go to **Repos** → **Add Repo** → Paste your Git URL
   - Click **Clone**
   - Run each notebook as part of a DLT pipeline

## Run Order

1. `bronze/bronze_ingest.py`
2. `silver/silver_product.py`
3. `silver/silver_pos.py`
4. `silver/silver_validation.py`
5. `gold/gold_kpis.py`

---
