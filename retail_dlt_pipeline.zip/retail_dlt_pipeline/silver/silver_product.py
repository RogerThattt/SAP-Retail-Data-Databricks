import dlt
from pyspark.sql.functions import trim, col

@dlt.table(name="product_silver")
def clean_product_master():
    return (
        dlt.read("sap_product_master_bronze")
        .filter(col("material_id").isNotNull())
        .withColumn("material_id", trim(col("material_id")))
        .withColumn("category", trim(col("category")))
    )
