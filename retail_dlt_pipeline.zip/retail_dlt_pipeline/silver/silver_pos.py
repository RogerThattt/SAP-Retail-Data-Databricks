import dlt
from pyspark.sql.functions import col

@dlt.table(name="pos_transactions_silver")
def enrich_pos_transactions():
    return (
        dlt.read("sap_pos_transactions_bronze")
        .filter(col("transaction_id").isNotNull())
        .join(dlt.read("product_silver"), on="material_id", how="left")
        .withColumn("total_amount", col("quantity") * col("unit_price"))
    )
