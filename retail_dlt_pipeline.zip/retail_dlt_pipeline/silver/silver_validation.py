import dlt

@dlt.expect("valid_price", "unit_price > 0")
@dlt.expect_or_drop("non_null_material", "material_id IS NOT NULL")
@dlt.table(name="validated_pos_transactions")
def validate_transactions():
    return dlt.read("pos_transactions_silver")
