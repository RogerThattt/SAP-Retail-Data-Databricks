import dlt
from pyspark.sql.functions import current_timestamp
from config import params

@dlt.table(name="sap_pos_transactions_bronze")
def load_pos_transactions():
    return (
        spark.read.format("delta").load(f"{params.bronze_path}/pos_transactions")
        .withColumn("ingest_time", current_timestamp())
    )

@dlt.table(name="sap_product_master_bronze")
def load_product_master():
    return (
        spark.read.format("delta").load(f"{params.bronze_path}/product_master")
        .withColumn("ingest_time", current_timestamp())
    )
