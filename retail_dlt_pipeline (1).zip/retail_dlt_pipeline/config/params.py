# config/params.py

bronze_path = "/mnt/bronze/sap"
silver_path = "/mnt/silver/retail"
gold_path = "/mnt/gold/retail"

bronze_schema = "retail_bronze"
silver_schema = "retail_silver"
gold_schema = "retail_gold"
