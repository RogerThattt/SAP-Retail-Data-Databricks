def test_valid_product_schema(spark):
    df = spark.read.table("retail_silver.product_silver")
    assert "material_id" in df.columns
    assert df.filter("material_id IS NULL").count() == 0

def test_kpi_aggregates_exist(spark):
    df = spark.read.table("retail_gold.store_weekly_revenue")
    assert df.count() > 0
