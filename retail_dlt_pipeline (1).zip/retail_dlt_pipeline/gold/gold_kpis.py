import dlt
from pyspark.sql.functions import sum, weekofyear, col

@dlt.table(name="store_weekly_revenue")
def gold_kpis():
    df = dlt.read("validated_pos_transactions")
    return (
        df.withColumn("week_of_year", weekofyear(col("transaction_date")))
          .groupBy("store_id", "week_of_year")
          .agg(sum("total_amount").alias("weekly_revenue"))
    )
